# KhanhOS AI — Cerebras/Vercel hotfix

## Vercel Environment Variables

Required:

```env
CEREBRAS_API_KEY=csk-...
CEREBRAS_MODEL=gpt-oss-120b
AUTH_SECRET=at-least-32-random-characters
DATABASE_URL=your-production-database-url
```

Optional diagnostic endpoint:

```env
CEREBRAS_TEST_SECRET=make-a-long-random-secret
```

After changing Environment Variables, create a new deployment.

## Test Cerebras without Prisma/auth

Send a GET request to `/api/cerebras-test` with this header:

`x-cerebras-test-secret: <your CEREBRAS_TEST_SECRET>`

Expected JSON contains `ok: true`, `provider: "cerebras"`, and `model: "gpt-oss-120b"`.

## Important Vercel database note

The project currently uses Prisma with SQLite. SQLite is not a suitable persistent production database on Vercel. If `/api/cerebras-test` returns `ok: true` but `/api/chat` still fails, the Cerebras connection is working and the next issue to fix is the production database/auth layer.

## Main changes

- Force `/api/chat` to Node.js runtime and dynamic execution.
- Respect `CEREBRAS_MODEL` instead of silently ignoring it.
- Keep `gpt-oss-120b` as the default.
- Add a secret-protected Cerebras diagnostic endpoint that does not use Prisma.
- Add `prisma generate` to `postinstall` for Vercel builds.
- Surface fatal streaming/server errors to the client and Vercel logs.
