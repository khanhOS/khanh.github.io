import { completeCerebrasChat, getCerebrasModel } from '@/lib/cerebras'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 30

export async function GET(request: Request) {
  const secret = process.env.CEREBRAS_TEST_SECRET?.trim()
  if (!secret) {
    return Response.json({ ok: false, error: 'CEREBRAS_TEST_SECRET chưa được cấu hình' }, { status: 503 })
  }

  const provided = request.headers.get('x-cerebras-test-secret')?.trim()
  if (!provided || provided !== secret) {
    return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const result = await completeCerebrasChat({
      model: getCerebrasModel(),
      messages: [
        { role: 'system', content: 'Trả lời cực ngắn để kiểm tra API.' },
        { role: 'user', content: 'Trả lời: OK' },
      ],
      maxTokens: 8,
      temperature: 0,
    })

    return Response.json({
      ok: true,
      provider: 'cerebras',
      model: getCerebrasModel(),
      response: result.content,
      usage: { inputTokens: result.inputTokens, outputTokens: result.outputTokens },
    })
  } catch (error) {
    const e = error as { status?: number; message?: string }
    return Response.json({
      ok: false,
      provider: 'cerebras',
      model: getCerebrasModel(),
      status: e.status || 500,
      error: e.message || 'Cerebras request failed',
    }, { status: e.status && e.status >= 400 && e.status < 600 ? e.status : 500 })
  }
}
